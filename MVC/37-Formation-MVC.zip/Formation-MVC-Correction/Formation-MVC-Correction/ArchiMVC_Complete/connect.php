<?php
define("BASE","formation2");
define("SERVER","localhost:3308");
define("USER","root");
define("PASSWD","");
?>